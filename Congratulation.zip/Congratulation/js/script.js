// scripts by Mona Ashmawey UX/UI designer (Alterna) for ID printing


// //change header color when scroll
// $(window).scroll(function() {
//   if ($(document).scrollTop() > 160) {
//     $(".dt-buttons, .dataTables_filter").addClass("scrolled");
//   } else {
//     $(".dt-buttons, .dataTables_filter").removeClass("scrolled");
//   }
// });


// datatables
// $('#all_employee').DataTable({
//   fixedHeader: true,
//   columnDefs: [{
//     orderable: false,
//     className: 'select-checkbox',
//     targets: 0
//   }],
//
//   dom: 'Bfrtip',
//   buttons: [
//     'selectAll',
//     'selectNone',
//     'excel',
//     {
//       extend: 'print',
//       exportOptions: {
//         columns: ':visible',
//         stripHtml: false
//       },
//       customize: function(win) {
//         $(win.document.body)
//         // .css(  )
//         // .prepend(
//         //     '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
//         // );
//
//         $(win.document.body).find('table tr')
//           .addClass('ids-item')
//           .prepend(
//             '<td><img src="file:///Users/mona/Desktop/id%20printing/imgs/CCHF_light.png" class="logo" /></td>'
//           );
//         // .css( 'font-size', 'inherit' );
//       }
//
//     },
//     // 'colvis'
//   ],
//   select: true,
//
//   language: {
//     buttons: {
//       selectAll: "<i class='fas fa-user-check'></i>Select all Employees",
//       selectNone: "<i class='fas fa-user-minus'></i>Unselect all",
//       excel: "<i class='fas fa-file-export'></i>Export Excel",
//       print: "<i class='fas fa-print'></i>Print Selected"
//     }
//   },
//
//   select: {
//     style: 'multi',
//     selector: 'td:first-child',
//
//   },
//   order: [
//     [1, 'asc']
//   ]
// });
// new $.fn.dataTable.FixedHeader(table);

//get data from inputs(view paage)
// var element = $("#capture"); // global variable
// var getCanvas; // global variable
//
//     $("#btn-Preview-Image").on('click', function () {
//          html2canvas(element, {
//          onrendered: function (canvas) {
//                 $("#previewImage").append(canvas);
//                 getCanvas = canvas;
//              }
//          });
//     });
//
// 	$("#btn-Convert-Html2Image").on('click', function () {
//     var imgageData = getCanvas.toDataURL("image/png");
//     // Now browser starts downloading it instead of just showing it
//     var newData = imgageData.replace(/^data:image\/png/, "data:application/octet-stream");
//     $("#btn-Convert-Html2Image").attr("download", "your_pic_name.png").attr("href", newData);
//
// 	});

function sendData() {
        html2canvas(document.getElementById('capture')).then(function (canvas) {
                $('#capture').append(canvas);
                $('#test').attr('href', canvas.toDataURL('image/png'));
                $('#test').attr('download', 'Test.png');
                $('#test')[0].click();
            });
        }



function myFunction() {
  var x = document.getElementById("name1").value;
  document.getElementById("name").innerHTML = x;

  // var y = document.getElementById("title1").value;
  // document.getElementById("title").innerHTML = y;
  //
  // var z = document.getElementById("code1").value;
  // document.getElementById("code").innerHTML = z;

  var a = document.getElementById("avatar").src;
  document.getElementById("avatar1").src = a;
}

//cropper

//upload and crop (view page)
window.addEventListener('DOMContentLoaded', function() {
  var avatar = document.getElementById('avatar');
  var image = document.getElementById('image_view');
  var input = document.getElementById('input');
  var $progress = $('.progress');
  var $progressBar = $('.progress-bar');
  var $alert = $('.alert');
  var $modal = $('#modal_view');
  var cropper;

  $('[data-toggle="tooltip"]').tooltip();

  input.addEventListener('change', function(e) {
    var files = e.target.files;
    var done = function(url) {
      input.value = '';
      image.src = url;
      $alert.hide();
      $modal.modal('show');
    };
    var reader;
    var file;
    var url;

    if (files && files.length > 0) {
      file = files[0];

      if (URL) {
        done(URL.createObjectURL(file));
      } else if (FileReader) {
        reader = new FileReader();
        reader.onload = function(e) {
          done(reader.result);
        };
        reader.readAsDataURL(file);
      }
    }
  });

  $modal.on('shown.bs.modal', function() {
    cropper = new Cropper(image, {
      aspectRatio: 1,
      viewMode: 0.5,
    });
  }).on('hidden.bs.modal', function() {
    cropper.destroy();
    cropper = null;
  });

  document.getElementById('crop').addEventListener('click', function() {
    var initialAvatarURL;
    var canvas;

    $modal.modal('hide');

    if (cropper) {
      canvas = cropper.getCroppedCanvas({
        width: 160,
        height: 160,
      });
      initialAvatarURL = avatar.src;
      avatar.src = canvas.toDataURL();

    }
  });
});


// crop from modal (upload page)
window.addEventListener('DOMContentLoaded', function() {
  var image = document.getElementById('image');
  var cropBoxData;
  var canvasData;
  var cropper;

  $('#modal').on('shown.bs.modal', function() {
    var cropper = new Cropper(image, {
      aspectRatio: 1,
      // viewMode: 3,
      ready: function() {
        var image = new Image();
      },
    });
    // On crop button clicked
    document.getElementById('crop_button').addEventListener('click', function() {
      var imgurl = cropper.getCroppedCanvas().toDataURL();
      var img = document.createElement("img");
      img.src = imgurl;
      document.getElementById("result").appendChild(img);

      /* ---------------- SEND IMAGE TO THE SERVER-------------------------

      cropper.getCroppedCanvas().toBlob(function (blob) {
      var formData = new FormData();
      formData.append('croppedImage', blob);
      // Use `jQuery.ajax` method
      $.ajax('/path/to/upload', {
      method: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function () {
      console.log('Upload success');
    },
    error: function () {
    console.log('Upload error');
  }
});
});
----------------------------------------------------*/

    }).on('hidden.bs.modal', function() {
      cropBoxData = cropper.getCropBoxData();
      canvasData = cropper.getCanvasData();
      cropper.destroy();
    });
  });


});














//buttons styles
$(".dt-buttons button").removeClass("dt-button").addClass("btn");
$(".dt-buttons button.buttons-select-all").addClass("btn-secondary");
$(".dt-buttons button.buttons-select-none").addClass("btn-danger");
$(".dt-buttons button.buttons-excel").addClass("btn-success");
$(".dt-buttons button.buttons-print").addClass("btn-primary");
